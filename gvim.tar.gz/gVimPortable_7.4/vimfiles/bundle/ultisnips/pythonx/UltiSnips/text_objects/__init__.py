#!/usr/bin/env python
# encoding: utf-8

"""Public facing classes for TextObjects."""

from ._snippet_instance import SnippetInstance
