UltiSnips
=========

This is the official repository for UltiSnips. Send Pull request to
SirVer/ultisnips, not the automatic clone from vim-scripts or any
other fork of this project.

Screencasts
-----------

The blog posts of the screencasts contain more advanced examples of the things
discussed in the videos.

* `Episode 1: What are snippets and do I need them?`__
* `Episode 2: Creating Basic Snippets`__
* `Episode 3: What's new in version 2.0`__
* `Episode 4: Python Interpolation`__

__ http://www.sirver.net/blog/2011/12/30/first-episode-of-ultisnips-screencast/
__ http://www.sirver.net/blog/2012/01/08/second-episode-of-ultisnips-screencast/
__ http://www.sirver.net/blog/2012/02/05/third-episode-of-ultisnips-screencast/
__ http://www.sirver.net/blog/2012/03/31/fourth-episode-of-ultisnips-screencast/
